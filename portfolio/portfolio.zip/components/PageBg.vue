<template>
    <div class="columns main">
        <div class="column blue"></div>
        <div class="column darkblue"></div>
    </div>
</template>

<style scoped>

.main{
    z-index: -1;
    width: 100vw;
    height: 100vh;
    margin: 0;
}
.blue{
    background-color: #3DBEEF;
}

.darkblue{
    background-color: #35444A;
}
</style>