<template>
  <div id="logo">
    <svg
      class="animated fadeInLeft shadow"
      id="slow"
      width="200%"
      height="200%"
      viewBox="0 0 1000 440"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      xml:space="preserve"
      xmlns:serif="http://www.serif.com/"
      style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;">
      <g transform="matrix(1,0,0,1,-13,36)">
        <g transform="matrix(200,0,0,200,19,197)">
          <path
            d="M0.465,-0.146L0.208,-0.146L0.159,0L0.003,0L0.268,-0.711L0.404,-0.711L0.67,0L0.514,0L0.465,-0.146ZM0.248,-0.265L0.425,-0.265L0.336,-0.531L0.248,-0.265Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(200,0,0,200,153.57,197)">
          <path
            d="M0.318,-0.466L0.451,-0.711L0.62,-0.711L0.413,-0.358L0.625,0L0.455,0L0.318,-0.249L0.181,0L0.011,0L0.223,-0.358L0.016,-0.711L0.185,-0.711L0.318,-0.466Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(200,0,0,200,280.621,197)">
          <path
            d="M0.491,-0.308L0.21,-0.308L0.21,-0.118L0.54,-0.118L0.54,0L0.063,0L0.063,-0.711L0.539,-0.711L0.539,-0.592L0.21,-0.592L0.21,-0.423L0.491,-0.423L0.491,-0.308Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(200,0,0,200,393.121,197)">
          <path
            d="M0.21,-0.118L0.521,-0.118L0.521,0L0.063,0L0.063,-0.711L0.21,-0.711L0.21,-0.118Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
      </g>
      <g transform="matrix(1,0,0,1,121.122,-57.2083)">
        <g transform="matrix(133.333,0,0,133.333,224,385)">
          <path
            d="M0.642,0L0.496,0L0.496,-0.305L0.21,-0.305L0.21,0L0.063,0L0.063,-0.711L0.21,-0.711L0.21,-0.423L0.496,-0.423L0.496,-0.711L0.642,-0.711L0.642,0Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,319.378,385)">
          <path
            d="M0.465,-0.146L0.208,-0.146L0.159,0L0.003,0L0.268,-0.711L0.404,-0.711L0.67,0L0.514,0L0.465,-0.146ZM0.248,-0.265L0.425,-0.265L0.336,-0.531L0.248,-0.265Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,409.091,385)">
          <path
            d="M0.21,-0.118L0.521,-0.118L0.521,0L0.063,0L0.063,-0.711L0.21,-0.711L0.21,-0.118Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,481.292,385)">
          <rect
            x="0.073"
            y="-0.711"
            width="0.146"
            height="0.711"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,520.159,385)">
          <path
            d="M0.642,0L0.495,0L0.21,-0.468L0.21,0L0.063,0L0.063,-0.711L0.21,-0.711L0.496,-0.242L0.496,-0.711L0.642,-0.711L0.642,0Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,612.411,385)">
          <path
            d="M0.599,-0.592L0.381,-0.592L0.381,0L0.234,0L0.234,-0.592L0.02,-0.592L0.02,-0.711L0.599,-0.711L0.599,-0.592Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,687.086,385)">
          <path
            d="M0.465,-0.146L0.208,-0.146L0.159,0L0.003,0L0.268,-0.711L0.404,-0.711L0.67,0L0.514,0L0.465,-0.146ZM0.248,-0.265L0.425,-0.265L0.336,-0.531L0.248,-0.265Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
        <g transform="matrix(133.333,0,0,133.333,776.799,385)">
          <path
            d="M0.327,-0.26L0.21,-0.26L0.21,0L0.063,0L0.063,-0.711L0.328,-0.711C0.412,-0.711 0.476,-0.692 0.522,-0.655C0.568,-0.617 0.59,-0.564 0.59,-0.496C0.59,-0.448 0.58,-0.407 0.559,-0.375C0.538,-0.342 0.506,-0.317 0.463,-0.297L0.617,-0.007L0.617,0L0.46,0L0.327,-0.26ZM0.21,-0.379L0.328,-0.379C0.365,-0.379 0.393,-0.388 0.414,-0.407C0.434,-0.426 0.444,-0.451 0.444,-0.484C0.444,-0.518 0.434,-0.544 0.415,-0.563C0.396,-0.583 0.367,-0.592 0.328,-0.592L0.21,-0.592L0.21,-0.379Z"
            style="fill:white;fill-rule:nonzero;"
          />
        </g>
      </g>
    </svg>
    <p class="primary animated infinite bounce delay-2s" id="Heading">"Color is king"</p>
    <p class="primary" id="nonHeading">Full Stack Web Developer</p>
  </div>
</template>

<script>
export default {
  head() {
    return {
      link: [
        {
          rel: "stylesheet",
          href: "https://fonts.googleapis.com/css?family=Roboto&display=swap"
        },
        {
          rel: "stylesheet",
          href:
            "https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.css"
        }
      ],
      methods: {
        
      },
    };
  }
};
</script>

<style scoped>
#slow{
    animation-duration: 3s;

}
.shadow {
  -webkit-filter: drop-shadow( 3px 3px 2px rgba(45, 76, 94, 0.192));
  filter: drop-shadow( 3px 3px 2px rgba(45, 76, 94, 0.212));
}

#nonHeading {
  font-family: 'Roboto 400', sans-serif;
  padding-top: 3vh;
  font-size: 25px;
}
#Heading {
  font-family: 'Roboto', sans-serif;
  margin-top: 12vh;
  font-size: 63px;
}
.primary {
  color: white;
}
#logo {
  z-index: 3;
  position: absolute;
  margin-top: 25vh;
  margin-left: 5vw;
}
</style>

