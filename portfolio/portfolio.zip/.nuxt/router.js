import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _470bd97c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _6742983b = () => interopDefault(import('..\\pages\\index\\about.vue' /* webpackChunkName: "pages_index_about" */))
const _5ee50c46 = () => interopDefault(import('..\\pages\\index\\athalia.vue' /* webpackChunkName: "pages_index_athalia" */))
const _1f299056 = () => interopDefault(import('..\\pages\\index\\Atomy.vue' /* webpackChunkName: "pages_index_Atomy" */))
const _b90b6c64 = () => interopDefault(import('..\\pages\\index\\contact.vue' /* webpackChunkName: "pages_index_contact" */))
const _9ffe3738 = () => interopDefault(import('..\\pages\\index\\mobile.vue' /* webpackChunkName: "pages_index_mobile" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
      path: "/",
      component: _470bd97c,
      name: "index",
      children: [{
        path: "about",
        component: _6742983b,
        name: "index-about"
      }, {
        path: "athalia",
        component: _5ee50c46,
        name: "index-athalia"
      }, {
        path: "Atomy",
        component: _1f299056,
        name: "index-Atomy"
      }, {
        path: "contact",
        component: _b90b6c64,
        name: "index-contact"
      }, {
        path: "mobile",
        component: _9ffe3738,
        name: "index-mobile"
      }]
    }],

  fallback: false
}

export function createRouter() {
  return new Router(routerOptions)
}
