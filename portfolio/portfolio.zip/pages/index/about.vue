<template>
  <div id="position">
   <h1>I LOVE </h1>
</template>

<style scoped>
a{
  color: #aeb6b9;
}
h1{
    font-family: "Roboto", sans-serif;
  font-size:5vw;
}

strong{
  color: #3DBEEF;
}

#position {
  color: #aeb6b9;
  margin-left: 55vw;
  margin-top: 20vh;
  position: absolute;
  height: 50vh;
  width: 40vw;
}
</style>