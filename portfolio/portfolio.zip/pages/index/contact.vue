<template>
  <div id="position">
    <h1>Let's <h2>Create</h2>  <strong>Something Amazing!</strong> </h1>
    <section> Email : <a href="mailto:axeldevara@gmail.com">axeldevara@gmail.com</a>  
    Mobile : <a href="tel:+61 4520 76669">+61 4520 76669</a> 
    LinkedIn : <a href="https://www.linkedin.com/in/axel-halintar">/in/axel-halintar</a></section>
  </div>
</template>

<style scoped>
a{
  color: #aeb6b9;
}
h1{
    font-family: "Roboto", sans-serif;
  font-size:5vw;
}

strong{
  color: #3DBEEF;
}

#position {
  color: #aeb6b9;
  margin-left: 55vw;
  margin-top: 20vh;
  position: absolute;
  height: 50vh;
  width: 40vw;
}
</style>