<template>
  <div id="position">
    <img src="~assets/atha.png" width="500px" height="300px" alt />
    <div id="second">
        <img src="~assets/athalia2.jpg" width="400px" height="200px" alt />
    </div>
    
  </div>
</template>

<style scoped>
#second{
    z-index: inherit;
    position: absolute;
    margin-left: 15vw;
    margin-top: 5vw;
}
#position {
  margin-left: 55vw;
  margin-top: 10vh;
  position: absolute;
  height: 50vh;
  width: 40vw;
}
</style>