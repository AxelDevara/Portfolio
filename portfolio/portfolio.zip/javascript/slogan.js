let arr = ['"Color Is King"', '"User Is King(?)"', '"Uhh, You are King?"', '"Stop Clicking Me!"']

arr()